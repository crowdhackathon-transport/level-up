https://api.foursquare.com/v2/venues/search
  ?client_id=FTVMB1ILXKIARFOPI0ACBVWDJLV1GHIEGCGYQPRZOQGO3OEN
  &client_secret=RMPGPFTFMCKKKPAG0ZK43M01AGV211ATOPMT5S3GOWKWWRVW
  &v=20130815
  &ll=40.7,-74
  &query=sushi
  
https://api.foursquare.com/v2/venues/explore?ll=40.7,-74&oauth_token=FXIBMUXBFJTSCNRUOZBMGAK2KHFOZFHR4X2USROMFKHYPS5H&v=20150707

categories
https://api.foursquare.com/v2/venues/categories?oauth_token=FXIBMUXBFJTSCNRUOZBMGAK2KHFOZFHR4X2USROMFKHYPS5H&v=20150707

